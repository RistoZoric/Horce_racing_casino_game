=== CTL Horse Racing ===
Tags: horse, virtual horses, horse race, horse racing, casino, casino games, 3d, gambling games, 3d game, 3d casino game, poker, slot, virtual horse, virtual racing, video poker
Requires at least: 4.3
Tested up to: 4.3

Add Horse Racing to CTL Arcade plugin

== Description ==
Add Horse Racing to CTL Arcade plugin


	